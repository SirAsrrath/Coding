for i in range (151):
    print(i)

for i in range (5,1001,5):
    print (i)

for i in range (1,101):
    if (i % 10 == 0):
        print ('Coding Dojo')
    elif (i % 5 == 0):
        print ('Coding ')
    else:
        print (i)

sum = 0
for i in range (500001):
    if (i % 2 !=0):
        sum += i
print (sum)

for i in range (2018,0,-4):
    print (i)

lowNum = input('Enter a low number =')
highNum = input('Enter high number =')
mult = input('Enter the multiple =')


for i in range( int(lowNum) , int(highNum) + 1):
    if i % int(mult) == 0:
        print(i)