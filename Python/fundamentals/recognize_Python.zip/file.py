num1 = 42 #Variable declaration, initializing integer
num2 = 2.3 #Variable declaration, initializing float
boolean = True # log statement, initializing boolean
string = 'Hello World' # log statement , initializing string
pizza_toppings = ['Pepperoni', 'Sausage', 'Jalepenos', 'Cheese', 'Olives'] #List initialize
person = {'name': 'John', 'location': 'Salt Lake', 'age': 37, 'is_balding': False} #Dictionary initialize
fruit = ('blueberry', 'strawberry', 'banana') #Tuple initialize
print(type(fruit)) # prints class tuple
print(pizza_toppings[1]) #prints sausage
pizza_toppings.append('Mushrooms') #adds item to pizza_toppings 
print(person['name']) #prints class name inside dictionary
person['name'] = 'George' #changes data in dictionary, class name is noe George
person['eye_color'] = 'blue' #adds new class and value to dictionary
print(fruit[2]) #prints banana

if num1 > 45: #prints It's lower/ initialize conditional
    print("It's greater")
else:
    print("It's lower")

if len(string) < 5: #prints just right!, initialize conditional
    print("It's a short word!")
elif len(string) > 15:
    print("It's a long word!")
else:
    print("Just right!")

for x in range(5): #for loop / first one prints numbers 0 through 4
for x in range(2,5): #for loop, prints numbers 2 through 4
    print(x)
for x in range(2,10,3): #for loop, creates parameters for it, numbers between 2 and 10, but counting only every three numbers
    print(x)
x = 0
while(x < 5): #for loop, adds counter in the parameters
    print(x)
    x += 1

pizza_toppings.pop() #deletes mushrooms from list
pizza_toppings.pop(1) #deletes sausage from list

print(person) #prints dictionary
person.pop('eye_color')#deletes class eye color
print(person) #prints dictionary

for topping in pizza_toppings: #for loop going through pizza toppings
    if topping == 'Pepperoni':
        continue
    print('After 1st if statement')
    if topping == 'Olives':
        break #ends for loop

def print_hello_ten_times(): #declares function 
    for num in range(10):
        print('Hello')

print_hello_ten_times() # calls function

def print_hello_x_times(x): #defines function
    for num in range(x):
        print('Hello')

print_hello_x_times(4) #calls function with parameter

def print_hello_x_or_ten_times(x = 10): #declares function
    for num in range(x):
        print('Hello')

print_hello_x_or_ten_times() #calls function, for loop executes 10 times
print_hello_x_or_ten_times(4) #calls function, for loop executes 4 times


"""
Bonus section
"""

print(num3) #undefined variable
num3 = 72 #defining variable
fruit[0] = 'cranberry'#tuple change value
print(person['favorite_team']) #key error, class doesnt exist
print(pizza_toppings[7]) # index error
print(boolean)
fruit.append('raspberry')#attribute error tuple cant be modified
fruit.pop(1)#attribute error tuple cant be modified