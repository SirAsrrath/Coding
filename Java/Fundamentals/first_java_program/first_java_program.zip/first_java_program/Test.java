public class Test {
    public static void main(String[] args){
        System.out.println("My name is Coding Dojo");
        System.out.println("I am 28 years old");
        System.out.println("My hometown is Greenville, SC");
    }
}