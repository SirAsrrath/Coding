package com.codingdojo.blackbelt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlackBeltApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlackBeltApplication.class, args);
	}

}
