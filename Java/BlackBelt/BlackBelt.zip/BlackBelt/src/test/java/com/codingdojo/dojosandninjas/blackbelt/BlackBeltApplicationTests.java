package com.codingdojo.dojosandninjas.blackbelt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlackBeltApplicationTests {

	@Test
	void contextLoads() {
	}

}
