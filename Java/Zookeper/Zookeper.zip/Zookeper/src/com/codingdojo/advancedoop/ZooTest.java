package com.codingdojo.advancedoop;

public class ZooTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Gorilla instance
		Gorilla harambe = new Gorilla(100);
		
		// Gorilla Test
		harambe.throwSomething();
		harambe.throwSomething();
		harambe.throwSomething();
		harambe.eatBananas();
		harambe.eatBananas();
		harambe.climb();
		harambe.displayEnergy();
		
		//Bat Instance
		Bat bruceWayne = new Bat(300);
		
		//Bat Test
		bruceWayne.attackTown();
		bruceWayne.attackTown();
		bruceWayne.attackTown();
		bruceWayne.eatHumans();
		bruceWayne.eatHumans();
		bruceWayne.fly();
		bruceWayne.fly();
		bruceWayne.displayEnergy();
		
		

	}

}
